import { SiteContent, Language, MarriageProfile } from './types';
import { v4 as uuidv4 } from 'uuid';

const DONATION_QR_CODE = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAI6ElVR42u3dQY7jMBAF0Pz/07vHChy1u0QJ6o5HsaEDaCspfuRPPvnkkyf/BDg88uSBDyBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgA-JAAAAAElFTkSuQmCC";

// FIX: Renamed variable from DEFAULT_-CONTENT to DEFAULT_CONTENT to fix syntax error.
export const DEFAULT_CONTENT: SiteContent = {
  appName: {
    [Language.EN]: 'Sarvangini',
    [Language.MR]: 'सर्वांगिनी',
    [Language.HI]: 'सर्वांगिनी',
  },
  tagline: {
    [Language.EN]: 'Serving Society, Uniting Hearts',
    [Language.MR]: 'समाजसेवा, हृदयांचे मिलन',
    [Language.HI]: 'समाज सेवा, दिलों का मिलन',
  },
  languageSelector: {
    [Language.EN]: 'Select Language',
    [Language.MR]: 'भाषा निवडा',
    [Language.HI]: 'भाषा चुनें',
  },
  header: {
    toggleTheme: { [Language.EN]: 'Toggle theme', [Language.MR]: 'थीम बदला', [Language.HI]: 'थीम बदलें' },
    openMenu: { [Language.EN]: 'Open main menu', [Language.MR]: 'मुख्य मेनू उघडा', [Language.HI]: 'मुख्य मेनू खोलें' },
    languageNames: {
      en: { [Language.EN]: 'English', [Language.MR]: 'English', [Language.HI]: 'English' },
      mr: { [Language.EN]: 'Marathi', [Language.MR]: 'मराठी', [Language.HI]: 'मराठी' },
      hi: { [Language.EN]: 'Hindi', [Language.MR]: 'हिन्दी', [Language.HI]: 'हिन्दी' },
    }
  },
  nav: {
    home: { [Language.EN]: 'Home', [Language.MR]: 'मुख्यपृष्ठ', [Language.HI]: 'होम' },
    marriage: { [Language.EN]: 'Marriage Bureau', [Language.MR]: 'विवाह जुळवणे', [Language.HI]: 'विवाह ब्यूरो' },
    profiles: { [Language.EN]: 'Profiles', [Language.MR]: 'प्रोफाइल्स', [Language.HI]: 'प्रोफाइल्स' },
    socialWork: { [Language.EN]: 'Our Social Work', [Language.MR]: 'आमचे सामाजिक कार्य', [Language.HI]: 'हमारे सामाजिक कार्य' },
    about: { [Language.EN]: 'About Us', [Language.MR]: 'आमच्याबद्दल', [Language.HI]: 'हमारे बारे में' },
    contact: { [Language.EN]: 'Contact Us', [Language.MR]: 'संपर्क साधा', [Language.HI]: 'हमसे संपर्क करें' },
    donate: { [Language.EN]: 'Donate', [Language.MR]: 'देणगी द्या', [Language.HI]: 'दान करें' },
    adminLogin: { [Language.EN]: 'Admin Login', [Language.MR]: 'प्रशासक लॉगिन', [Language.HI]: 'एडमिन लॉगिन' },
  },
  homepage: {
    heroImage: 'https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    welcomeMessage: {
      [Language.EN]: 'Welcome to Sarvangini Multipurpose Organization. Our mission is to serve society and bring hearts together through meaningful social work and dedicated matrimonial services.',
      [Language.MR]: 'सर्वांगिनी बहुउद्देशीय संस्थेत आपले स्वागत आहे. आमचे ध्येय समाजसेवा करणे आणि समर्पित विवाह जुळवण्याच्या सेवांद्वारे हृदये एकत्र आणणे आहे.',
      [Language.HI]: 'सर्वांगिनी बहुउद्देशीय संस्था में आपका स्वागत है। हमारा मिशन समाज की सेवा करना और समर्पित वैवाहिक सेवाओं के माध्यम से दिलों को जोड़ना है।',
    },
    quickLinks: {
      marriageTitle: { [Language.EN]: 'Find Your Partner', [Language.MR]: 'तुमचा जीवनसाथी शोधा', [Language.HI]: 'अपना जीवनसाथी ढूंढें' },
      marriageDesc: { [Language.EN]: 'Begin your journey to find a life partner with our trusted matrimonial services.', [Language.MR]: 'आमच्या विश्वसनीय विवाह सेवांसह जीवनसाथी शोधण्याच्या आपल्या प्रवासाची सुरुवात करा.', [Language.HI]: 'हमारी विश्वसनीय वैवाहिक सेवाओं के साथ एक जीवन साथी खोजने की अपनी यात्रा शुरू करें।' },
      socialWorkTitle: { [Language.EN]: 'Our Community Work', [Language.MR]: 'आमचे सामाजिक कार्य', [Language.HI]: 'हमारे सामुदायिक कार्य' },
      socialWorkDesc: { [Language.EN]: 'Explore the diverse social initiatives we undertake to uplift our community.', [Language.MR]: 'आमच्या समुदायाला उन्नत करण्यासाठी आम्ही हाती घेतलेल्या विविध सामाजिक उपक्रमांबद्दल जाणून घ्या.', [Language.HI]: 'हमारे समुदाय के उत्थान के लिए हमारे द्वारा किए गए विभिन्न सामाजिक पहलों का अन्वेषण करें।' },
    }
  },
  marriageSection: {
    title: { [Language.EN]: 'Marriage Section', [Language.MR]: 'विवाह जुळवणे', [Language.HI]: 'विवाह अनुभाग' },
    subheading: { [Language.EN]: 'Find your life partner with our help.', [Language.MR]: 'आमच्या मदतीने तुमचा जीवनसाथी शोधा.', [Language.HI]: 'हमारी मदद से अपना जीवनसाथी ढूंढें।' },
    description: {
      [Language.EN]: 'We provide comprehensive assistance for various types of marriages, including court marriage, traditional Hindu Vedic marriage, and specialized Brahmin rituals.',
      [Language.MR]: 'आम्ही कोर्ट मॅरेज, पारंपारिक हिंदू वैदिक विवाह आणि विशेष ब्राह्मण विधींसह विविध प्रकारच्या विवाहांसाठी व्यापक सहाय्य प्रदान करतो.',
      [Language.HI]: 'हम कोर्ट मैरिज, पारंपरिक हिंदू वैदिक विवाह, और विशेष ब्राह्मण अनुष्ठानों सहित विभिन्न प्रकार की शादियों के लिए व्यापक सहायता प्रदान करते हैं।',
    },
     oneStopSolution: {
      title: {
        [Language.EN]: 'A One-Stop Solution for Your Wedding',
        [Language.MR]: 'तुमच्या लग्नासाठी एक-स्टॉप समाधान',
        [Language.HI]: 'आपकी शादी के लिए एक-स्टॉप समाधान',
      },
      items: [
        { [Language.EN]: 'Court Marriage Assistance', [Language.MR]: 'कोर्ट मॅरेज सहाय्य', [Language.HI]: 'कोर्ट मैरिज सहायता' },
        { [Language.EN]: 'Traditional Brahmin Rituals', [Language.MR]: 'पारंपारिक ब्राह्मण विधी', [Language.HI]: 'पारंपरिक ब्राह्मण अनुष्ठान' },
        { [Language.EN]: 'Marriage Hall Bookings', [Language.MR]: 'विवाह हॉल बुकिंग', [Language.HI]: 'मैरिज हॉल बुकिंग' },
        { [Language.EN]: 'Catering & Food Arrangements', [Language.MR]: 'केटरिंग आणि जेवणाची व्यवस्था', [Language.HI]: 'कैटरिंग और भोजन की व्यवस्था' },
      ],
    },
    form: {
      title: { [Language.EN]: 'Register Your Profile', [Language.MR]: 'तुमची प्रोफाइल नोंदवा', [Language.HI]: 'अपनी प्रोफ़ाइल पंजीकृत करें' },
      personalDetails: { [Language.EN]: 'Personal Details', [Language.MR]: 'वैयक्तिक तपशील', [Language.HI]: 'व्यक्तिगत विवरण' },
      name: { [Language.EN]: 'Full Name', [Language.MR]: 'पूर्ण नाव', [Language.HI]: 'पूरा नाम' },
      gender: { [Language.EN]: 'Gender', [Language.MR]: 'लिंग', [Language.HI]: 'लिंग' },
      male: { [Language.EN]: 'Male', [Language.MR]: 'पुरुष', [Language.HI]: 'पुरुष' },
      female: { [Language.EN]: 'Female', [Language.MR]: 'स्त्री', [Language.HI]: 'महिला' },
      other: { [Language.EN]: 'Other', [Language.MR]: 'इतर', [Language.HI]: 'अन्य' },
      photo: { [Language.EN]: 'Upload Photo', [Language.MR]: 'फोटो अपलोड करा', [Language.HI]: 'फोटो अपलोड करें' },
      dob: { [Language.EN]: 'Date of Birth', [Language.MR]: 'जन्म तारीख', [Language.HI]: 'जन्म तिथि' },
      address: { [Language.EN]: 'Address', [Language.MR]: 'पत्ता', [Language.HI]: 'पता' },
      phone: { [Language.EN]: 'Phone Number (Hidden from public)', [Language.MR]: 'फोन नंबर (सार्वजनिकरित्या लपवलेला)', [Language.HI]: 'फ़ोन नंबर (सार्वजनिक रूप से छिपा हुआ)' },
      email: { [Language.EN]: 'Email (Hidden from public)', [Language.MR]: 'ईमेल (सार्वजनिकरित्या लपवलेला)', [Language.HI]: 'ईमेल (सार्वजनिक रूप से छिपा हुआ)' },
      familyDetails: { [Language.EN]: 'Family Details', [Language.MR]: 'कौटुंबिक तपशील', [Language.HI]: 'परिवार का विवरण' },
      fatherName: { [Language.EN]: "Father's Name", [Language.MR]: 'वडिलांचे नाव', [Language.HI]: 'पिता का नाम' },
      motherName: { [Language.EN]: "Mother's Name", [Language.MR]: 'आईचे नाव', [Language.HI]: 'माता का नाम' },
      sisters: { [Language.EN]: 'Sister(s) Details', [Language.MR]: 'बहिणी(ंची) माहिती', [Language.HI]: 'बहन(नों) का विवरण' },
      brothers: { [Language.EN]: 'Brother(s) Details', [Language.MR]: 'भावा(ंची) माहिती', [Language.HI]: 'भाई(यों) का विवरण' },
      professionalDetails: { [Language.EN]: 'Professional Details', [Language.MR]: 'व्यावसायिक तपशील', [Language.HI]: 'व्यावसायिक विवरण' },
      job: { [Language.EN]: 'Job/Occupation', [Language.MR]: 'नोकरी/व्यवसाय', [Language.HI]: 'नौकरी/व्यवसाय' },
      salary: { [Language.EN]: 'Salary (e.g., 5 LPA)', [Language.MR]: 'पगार (उदा. ५ एलपीए)', [Language.HI]: 'वेतन (जैसे, 5 एलपीए)' },
      education: { [Language.EN]: 'Education', [Language.MR]: 'शिक्षण', [Language.HI]: 'शिक्षा' },
      culturalDetails: { [Language.EN]: 'Cultural & Religious Details', [Language.MR]: 'सांस्कृतिक आणि धार्मिक तपशील', [Language.HI]: 'सांस्कृतिक और धार्मिक विवरण' },
      gotra: { [Language.EN]: 'Gotra', [Language.MR]: 'गोत्र', [Language.HI]: 'गोत्र' },
      caste: { [Language.EN]: 'Caste', [Language.MR]: 'जात', [Language.HI]: 'जाति' },
      religion: { [Language.EN]: 'Religion', [Language.MR]: 'धर्म', [Language.HI]: 'धर्म' },
      expectations: { [Language.EN]: 'Expectations from Partner', [Language.MR]: 'जोडीदाराकडून अपेक्षा', [Language.HI]: 'जीवनसाथी से उम्मीदें' },
      consent: { [Language.EN]: 'I agree to the terms and conditions.', [Language.MR]: 'मी अटी आणि शर्तींना सहमत आहे.', [Language.HI]: 'मैं नियमों और शर्तों से सहमत हूँ।' },
      submit: { [Language.EN]: 'Submit Profile', [Language.MR]: 'प्रोफाइल सबमिट करा', [Language.HI]: 'प्रोफ़ाइल सबमिट करें' },
      paymentTitle: { [Language.EN]: 'Registration Fee & Payment', [Language.MR]: 'नोंदणी शुल्क आणि पेमेंट', [Language.HI]: 'पंजीकरण शुल्क और भुगतान' },
      paymentDesc: { [Language.EN]: 'A nominal registration fee is required. Please pay using the UPI ID below and your profile will be reviewed for approval.', [Language.MR]: 'एक नाममात्र नोंदणी शुल्क आवश्यक आहे. कृपया खालील UPI आयडी वापरून पैसे भरा आणि तुमची प्रोफाइल मंजुरीसाठी तपासली जाईल.', [Language.HI]: 'एक मामूली पंजीकरण शुल्क आवश्यक है। कृपया नीचे दिए गए UPI आईडी का उपयोग करके भुगतान करें और आपकी प्रोफ़ाइल को मंजूरी के लिए समीक्षा की जाएगी।' },
      formSuccess: { [Language.EN]: 'Thank you! Your profile has been submitted for review.', [Language.MR]: 'धन्यवाद! तुमची प्रोफाइल पुनरावलोकनासाठी सबमिट केली आहे.', [Language.HI]: 'धन्यवाद! आपकी प्रोफ़ाइल समीक्षा के लिए सबमिट कर दी गई है।' },
      formSuccessSub: { [Language.EN]: 'Please send your biodata to an admin via WhatsApp to complete the process.', [Language.MR]: 'कृपया प्रक्रिया पूर्ण करण्यासाठी तुमचा बायोडाटा व्हॉट्सॲपद्वारे प्रशासकाला पाठवा.', [Language.HI]: 'प्रक्रिया पूरी करने के लिए कृपया अपना बायोडाटा व्हाट्सएप के माध्यम से एक व्यवस्थापक को भेजें।' },
      sendBiodata: { [Language.EN]: 'Send Biodata via WhatsApp', [Language.MR]: 'व्हॉट्सॲपवर बायोडाटा पाठवा', [Language.HI]: 'व्हाट्सएप पर बायोडाटा भेजें' },
      sendTo: { [Language.EN]: 'Send to {name}', [Language.MR]: '{name} यांना पाठवा', [Language.HI]: '{name} को भेजें' },
    },
     filters: {
        title: { [Language.EN]: "Find Your Match", [Language.MR]: "तुमचा जोडीदार शोधा", [Language.HI]: "अपना मैच खोजें" },
        ageRange: { [Language.EN]: "Age Range", [Language.MR]: "वयोगट", [Language.HI]: "आयु सीमा" },
        from: { [Language.EN]: "From", [Language.MR]: "पासून", [Language.HI]: "से" },
        to: { [Language.EN]: "To", [Language.MR]: "पर्यंत", [Language.HI]: "तक" },
        caste: { [Language.EN]: "Caste", [Language.MR]: "जात", [Language.HI]: "जाति" },
        education: { [Language.EN]: "Education", [Language.MR]: "शिक्षण", [Language.HI]: "शिक्षा" },
        search: { [Language.EN]: "Search Profiles", [Language.MR]: "प्रोफाइल शोधा", [Language.HI]: "प्रोफ़ाइल खोजें" },
        gender: {
            label: { [Language.EN]: "Looking For", [Language.MR]: "शोधत आहे", [Language.HI]: "के लिए देख रहे हैं" },
            all: { [Language.EN]: "All", [Language.MR]: "सर्व", [Language.HI]: "सभी" },
            male: { [Language.EN]: "Groom (Male)", [Language.MR]: "वर (पुरुष)", [Language.HI]: "दूल्हा (पुरुष)" },
            female: { [Language.EN]: "Bride (Female)", [Language.MR]: "वधू (स्त्री)", [Language.HI]: "दुल्हन (महिला)" },
            other: { [Language.EN]: 'Other', [Language.MR]: 'इतर', [Language.HI]: 'अन्य' },
        }
    }
  },
  profilesPage: {
    title: { [Language.EN]: 'Matrimonial Profiles', [Language.MR]: 'वैवाहिक प्रोफाइल', [Language.HI]: 'वैवाहिक प्रोफाइल' },
    noProfiles: { [Language.EN]: 'No profiles match the current criteria.', [Language.MR]: 'सध्याच्या निकषांशी जुळणारे कोणतेही प्रोफाइल नाहीत.', [Language.HI]: 'वर्तमान मानदंडों से मेल खाने वाली कोई प्रोफ़ाइल नहीं है।' },
    contactAction: { [Language.EN]: "I'm Interested", [Language.MR]: 'मला आवड आहे', [Language.HI]: 'मुझे दिलचस्पी है' },
    ageString: { [Language.EN]: '{age} years old', [Language.MR]: '{age} वर्षे', [Language.HI]: '{age} साल' },
    details: {
        education: { [Language.EN]: 'Education', [Language.MR]: 'शिक्षण', [Language.HI]: 'शिक्षा' },
        occupation: { [Language.EN]: 'Occupation', [Language.MR]: 'व्यवसाय', [Language.HI]: 'व्यवसाय' },
        caste: { [Language.EN]: 'Caste', [Language.MR]: 'जात', [Language.HI]: 'जाति' },
    },
    interestMessage: {
        [Language.EN]: 'Hello, I am interested in the profile of {name} (ID: {id}). Please provide more details. Thank you.',
        [Language.MR]: 'नमस्कार, मला {name} (आयडी: {id}) यांच्या प्रोफाइलमध्ये आवड आहे. कृपया अधिक तपशील द्या. धन्यवाद.',
        [Language.HI]: 'नमस्ते, मुझे {name} (आईडी: {id}) की प्रोफाइल में दिलचस्पी है। कृपया अधिक जानकारी प्रदान करें। धन्यवाद।'
    }
  },
  socialWork: {
    title: { [Language.EN]: 'Our Social Work', [Language.MR]: 'आमचे सामाजिक कार्य', [Language.HI]: 'हमारे सामाजिक कार्य' },
    galleryTitle: { [Language.EN]: 'Activities Gallery', [Language.MR]: 'उपक्रम गॅलरी', [Language.HI]: 'गतिविधि गैलरी' },
    categories: [
      {
        id: 'old-age-home',
        title: { [Language.EN]: 'Old Age Home', [Language.MR]: 'वृद्धाश्रम', [Language.HI]: 'वृद्धाश्रम' },
        images: [
            {id: uuidv4(), src: 'https://images.pexels.com/photos/5778903/pexels-photo-5778903.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', caption: {en: 'Providing a safe and caring environment.', mr: 'सुरक्षित आणि काळजीपूर्ण वातावरण प्रदान करणे.', hi: 'एक सुरक्षित और देखभाल करने वाला वातावरण प्रदान करना।'}},
            {id: uuidv4(), src: 'https://images.pexels.com/photos/6647037/pexels-photo-6647037.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', caption: {en: 'Celebrating festivals together.', mr: 'एकत्र सण साजरे करणे.', hi: 'त्योहारों को एक साथ मनाना।'}},
            {id: uuidv4(), src: 'https://images.pexels.com/photos/4386466/pexels-photo-4386466.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', caption: {en: 'Daily health checkups for residents.', mr: 'रहिवाशांसाठी दैनिक आरोग्य तपासणी.', hi: 'निवासियों के लिए दैनिक स्वास्थ्य जांच।'}},
            {id: uuidv4(), src: 'https://images.pexels.com/photos/6913718/pexels-photo-6913718.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', caption: {en: 'Recreational activities and games.', mr: 'मनोरंजक उपक्रम आणि खेळ.', hi: 'मनोरंजक गतिविधियाँ और खेल।'}},
        ],
      },
      {
        id: 'rehabilitation-centre',
        title: { [Language.EN]: 'Rehabilitation Centre', [Language.MR]: 'पुनर्वसन केंद्र', [Language.HI]: 'पुनर्वास केंद्र' },
        images: [
            {id: uuidv4(), src: 'https://images.pexels.com/photos/7176036/pexels-photo-7176036.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', caption: {en: 'Helping individuals rebuild their lives.', mr: 'व्यक्तींना त्यांचे जीवन पुन्हा उभारण्यास मदत करणे.', hi: 'व्यक्तियों को उनके जीवन का पुनर्निर्माण करने में मदद करना।'}},
            {id: uuidv4(), src: 'https://images.pexels.com/photos/8942203/pexels-photo-8942203.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', caption: {en: 'Skill development programs.', mr: 'कौशल्य विकास कार्यक्रम.', hi: 'कौशल विकास कार्यक्रम।'}},
            {id: uuidv4(), src: 'https://images.pexels.com/photos/5699475/pexels-photo-5699475.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', caption: {en: 'Counseling and therapy sessions.', mr: 'समुपदेशन आणि थेरपी सत्रे.', hi: 'परामर्श और चिकित्सा सत्र।'}},
            {id: uuidv4(), src: 'https://images.pexels.com/photos/10810331/pexels-photo-10810331.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', caption: {en: 'Community support groups.', mr: 'समुदाय समर्थन गट.', hi: 'सामुदायिक सहायता समूह।'}},
        ],
      },
      {
        id: 'other-activities',
        title: { [Language.EN]: 'Various Other Activities', [Language.MR]: 'इतर विविध उपक्रम', [Language.HI]: 'अन्य विविध गतिविधियां' },
        images: [
            {id: uuidv4(), src: 'https://images.pexels.com/photos/6646917/pexels-photo-6646917.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', caption: {en: 'Food distribution drives for the needy.', mr: 'गरजूंसाठी अन्न वाटप मोहीम.', hi: 'जरूरतमंदों के लिए भोजन वितरण अभियान।'}},
            {id: uuidv4(), src: 'https://images.pexels.com/photos/8199736/pexels-photo-8199736.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', caption: {en: 'Educational support for underprivileged children.', mr: 'वंचित मुलांसाठी शैक्षणिक सहाय्य.', hi: 'वंचित बच्चों के लिए शैक्षिक सहायता।'}},
            {id: uuidv4(), src: 'https://images.pexels.com/photos/6822238/pexels-photo-6822238.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', caption: {en: 'Blood donation camps.', mr: 'रक्तदान शिबिरे.', hi: 'रक्तदान शिविर।'}},
            {id: uuidv4(), src: 'https://images.pexels.com/photos/8948346/pexels-photo-8948346.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', caption: {en: 'Environmental awareness programs.', mr: 'पर्यावरण जागरूकता कार्यक्रम.', hi: 'पर्यावरण जागरूकता कार्यक्रम।'}},
        ],
      },
    ],
    donateTitle: { [Language.EN]: 'Support Our Cause', [Language.MR]: 'आमच्या कार्याला पाठिंबा द्या', [Language.HI]: 'हमारे कारण का समर्थन करें' },
    donateDesc: { [Language.EN]: 'Your contribution makes a difference!', [Language.MR]: 'तुमचे योगदान फरक घडवते!', [Language.HI]: 'आपका योगदान एक अंतर बनाता है!' },
    donateButton: { [Language.EN]: 'Donate Now', [Language.MR]: 'आता देणगी द्या', [Language.HI]: 'अभी दान करें' },
  },
  aboutUs: {
    title: { [Language.EN]: 'About Sarvangini Multipurpose Organization', [Language.MR]: 'सर्वांगिनी बहुउद्देशीय संस्थेबद्दल', [Language.HI]: 'सर्वांगिनी बहुउद्देशीय संस्था के बारे में' },
    vision: { [Language.EN]: 'Vision', [Language.MR]: 'दृष्टी', [Language.HI]: 'दृष्टि' },
    mission: { [Language.EN]: 'Mission', [Language.MR]: 'ध्येय', [Language.HI]: 'उद्देश्य' },
    history: { [Language.EN]: 'History', [Language.MR]: 'इतिहास', [Language.HI]: 'इतिहास' },
    teamTitle: { [Language.EN]: 'Our Team', [Language.MR]: 'आमची टीम', [Language.HI]: 'हमारी टीम' },
    visionText: {
      [Language.EN]: 'To build a compassionate and self-reliant society where every individual has the opportunity to thrive with dignity and purpose. We envision a community where the elderly are cherished, the vulnerable are protected, and strong family bonds are the foundation of a prosperous future.',
      [Language.MR]: 'एक दयाळू आणि आत्मनिर्भर समाज तयार करणे जिथे प्रत्येक व्यक्तीला सन्मानाने आणि उद्देशाने प्रगती करण्याची संधी मिळेल. आम्ही अशा समुदायाची कल्पना करतो जिथे वृद्धांना जपले जाते, वंचितांचे संरक्षण केले जाते आणि मजबूत कौटुंबिक बंध समृद्ध भविष्याचा पाया असतात.',
      [Language.HI]: 'एक दयालु और आत्मनिर्भर समाज का निर्माण करना जहाँ प्रत्येक व्यक्ति को सम्मान और उद्देश्य के साथ आगे बढ़ने का अवसर मिले। हम एक ऐसे समुदाय की कल्पना करते हैं जहाँ बुजुर्गों को संजोया जाता है, कमजोरों की रक्षा की जाती है, और मजबूत पारिवारिक बंधन एक समृद्ध भविष्य की नींव होते हैं।',
    },
    missionText: {
      [Language.EN]: 'Sarvangini Multipurpose Organization is dedicated to serving the community through impactful social initiatives and trusted matrimonial services. We strive to support the elderly, empower the disadvantaged, and guide individuals in finding their life partners, fostering unity and happiness across Nashik.',
      [Language.MR]: 'सर्वांगिनी बहुउद्देशीय संस्था प्रभावी सामाजिक उपक्रम आणि विश्वसनीय विवाह सेवांद्वारे समाजाची सेवा करण्यासाठी समर्पित आहे. आम्ही वृद्धांना आधार देणे, वंचितांना सक्षम करणे आणि व्यक्तींना त्यांचे जीवनसाथी शोधण्यासाठी मार्गदर्शन करणे, नाशिकमध्ये एकता आणि आनंद वाढवणे यासाठी प्रयत्नशील आहोत.',
      [Language.HI]: 'सर्वांगिनी बहुउद्देशीय संस्था प्रभावशाली सामाजिक पहलों और विश्वसनीय वैवाहिक सेवाओं के माध्यम से समुदाय की सेवा के लिए समर्पित है। हम बुजुर्गों का समर्थन करने, वंचितों को सशक्त बनाने, और व्यक्तियों को उनके जीवन साथी खोजने में मार्गदर्शन करने का प्रयास करते हैं, जिससे नाशिक में एकता और खुशी को बढ़ावा मिलता है।',
    },
    historyText: {
      [Language.EN]: "Founded in Nashik, our organization grew from a simple desire to make a tangible difference in people's lives. What began as a small community effort has blossomed into a multi-faceted organization, driven by the unwavering dedication of our team and the generous support of our community.",
      [Language.MR]: 'नाशिकमध्ये स्थापित, आमची संस्था लोकांच्या जीवनात ठोस बदल घडवण्याच्या साध्या इच्छेतून वाढली. एका छोट्या सामुदायिक प्रयत्नापासून सुरू झालेली ही संस्था आता आमच्या टीमच्या अतूट समर्पणामुळे आणि आमच्या समुदायाच्या उदार पाठिंब्यामुळे एक बहुआयामी संस्था बनली आहे.',
      [Language.HI]: 'नाशिक में स्थापित, हमारा संगठन लोगों के जीवन में एक ठोस अंतर लाने की एक साधारण इच्छा से विकसित हुआ। जो एक छोटे सामुदायिक प्रयास के रूप में शुरू हुआ था, वह हमारी टीम के अटूट समर्पण और हमारे समुदाय के उदार समर्थन से प्रेरित होकर एक बहुआयामी संगठन के रूप में विकसित हुआ है।',
    },
    teamDetails: {
      phone: { [Language.EN]: 'Phone', [Language.MR]: 'फोन', [Language.HI]: 'फ़ोन' },
      email: { [Language.EN]: 'Email', [Language.MR]: 'ईमेल', [Language.HI]: 'ईमेल' },
    },
    team: [
        {
            id: 'nandini-gadakh',
            name: 'Nandini Gadakh',
            role: {en: 'Founder', mr: 'संस्थापक', hi: 'संस्थापक'},
            vision: {en: 'To create a society where everyone feels supported, valued, and has the opportunity to lead a dignified life.', mr: 'एक असा समाज निर्माण करणे जिथे प्रत्येकाला आधार, मूल्य आणि प्रतिष्ठित जीवन जगण्याची संधी मिळेल.', hi: 'एक ऐसा समाज बनाना जहाँ हर कोई समर्थित, मूल्यवान महसूस करे और उसे एक सम्मानजनक जीवन जीने का अवसर मिले।'},
            photo: 'https://images.pexels.com/photos/3762800/pexels-photo-3762800.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
        },
        {
            id: 'yashvant-nashikkar',
            name: 'Yashvant Nashikkar',
            role: {en: 'Rehabilitation Centre Head', mr: 'पुनर्वसन केंद्र प्रमुख', hi: 'पुनर्वास केंद्र प्रमुख'},
            vision: {en: 'To provide a safe haven for the homeless and destitute, helping them reintegrate into society with renewed hope.', mr: 'निराधार आणि बेघरांसाठी एक सुरक्षित आश्रयस्थान प्रदान करणे, त्यांना नवीन आशेने समाजात पुन्हा समाकलित होण्यास मदत करणे.', hi: 'बेघर और निराश्रितों के लिए एक सुरक्षित आश्रय प्रदान करना, उन्हें नई आशा के साथ समाज में फिर से एकीकृत करने में मदद करना।'},
            contact: '7588833277',
            photo: 'https://images.pexels.com/photos/5327585/pexels-photo-5327585.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
        },
        {
            id: 'mayur-gadakh',
            name: 'Mayur Gadakh',
            role: {en: 'Operations Lead', mr: 'कार्यकारी प्रमुख', hi: 'संचालन प्रमुख'},
            vision: {en: 'Inspired by my mother, my goal is to expand our reach and use technology to enhance our social and matrimonial services, connecting more lives meaningfully.', mr: 'माझ्या आईपासून प्रेरित होऊन, आमची पोहोच वाढवणे आणि आमच्या सामाजिक आणि वैवाहिक सेवा सुधारण्यासाठी तंत्रज्ञानाचा वापर करणे हे माझे ध्येय आहे, ज्यामुळे अधिक जीवन अर्थपूर्णपणे जोडले जातील.', hi: 'मेरी माँ से प्रेरित होकर, मेरा लक्ष्य हमारी पहुँच का विस्तार करना और हमारी सामाजिक और वैवाहिक सेवाओं को बढ़ाने के लिए प्रौद्योगिकी का उपयोग करना है, जिससे अधिक जीवन सार्थक रूप से जुड़ सकें।'},
            contact: '7972461024',
            email: 'mayur007gadakh@gmail.com',
            photo: 'https://images.pexels.com/photos/845457/pexels-photo-845457.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
        }
    ]
  },
  contactUs: {
    title: { [Language.EN]: 'Contact Us', [Language.MR]: 'संपर्क साधा', [Language.HI]: 'हमसे संपर्क करें' },
    getInTouch: { [Language.EN]: 'Get in Touch', [Language.MR]: 'संपर्कात रहा', [Language.HI]: 'संपर्क में रहें' },
    phones: [
      { name: 'Mayur Gadakh', number: '7972461024' },
      { name: 'Yashvant Nashikkar', number: '7588833277' },
    ],
    email: 'mayur007gadakh@gmail.com',
    address: { [Language.EN]: 'Nashik City, Maharashtra, India', [Language.MR]: 'नाशिक शहर, महाराष्ट्र, भारत', [Language.HI]: 'नासिक शहर, महाराष्ट्र, भारत' },
    mapEmbedUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d239966.3397395781!2d73.64912089339943!3d19.99113028303038!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bddd290b09914b3%3A0xcb07812d847648b8!2sNashik%2C%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1695573426865!5m2!1sen!2sin',
    labels: {
        phone: { [Language.EN]: 'Phone', [Language.MR]: 'फोन', [Language.HI]: 'फ़ोन' },
        email: { [Language.EN]: 'Email', [Language.MR]: 'ईमेल', [Language.HI]: 'ईमेल' },
        address: { [Language.EN]: 'Address', [Language.MR]: 'पत्ता', [Language.HI]: 'पता' },
    }
  },
  donatePage: {
    title: { [Language.EN]: 'Donate & Support Us', [Language.MR]: 'दान करा आणि आम्हाला पाठिंबा द्या', [Language.HI]: 'दान करें और हमारा समर्थन करें' },
    supportCause: { [Language.EN]: 'Support our cause. Your contribution makes a difference!', [Language.MR]: 'आमच्या कार्याला पाठिंबा द्या. तुमचे योगदान फरक घडवते!', [Language.HI]: 'हमारे कारण का समर्थन करें। आपका योगदान एक अंतर बनाता है!' },
    scanToPay: { [Language.EN]: 'Scan to Pay with any UPI App', [Language.MR]: 'कोणत्याही UPI अॅपने स्कॅन करून पैसे द्या', [Language.HI]: 'किसी भी UPI ऐप से स्कैन करके भुगतान करें' },
    directTransfer: { [Language.EN]: 'Or Transfer Directly', [Language.MR]: 'किंवा थेट हस्तांतरित करा', [Language.HI]: 'या सीधे ट्रांसफर करें' },
    upiId: '7972461024@kotak811',
    bankAccount: '6048893747',
    qrCode: DONATION_QR_CODE,
  },
  footer: {
    copyright: { [Language.EN]: '© 2023 Sarvangini Multipurpose Organization. All Rights Reserved.', [Language.MR]: '© २०२३ सर्वांगिनी बहुउद्देशीय संस्था. सर्व हक्क राखीव.', [Language.HI]: '© 2023 सर्वांगिनी बहुउद्देशीय संस्था। सर्वाधिकार सुरक्षित।' },
    quickLinks: { [Language.EN]: 'Quick Links', [Language.MR]: 'द्रुत दुवे', [Language.HI]: 'त्वरित लिंक्स' },
    followUs: { [Language.EN]: 'Follow Us', [Language.MR]: 'आम्हाला फॉलो करा', [Language.HI]: 'हमें फॉलो करें' },
    adminLogin: { [Language.EN]: 'Admin', [Language.MR]: 'प्रशासक', [Language.HI]: 'एडमिन' },
    facebookUrl: '',
    instagramUrl: '',
    youtubeUrl: '',
  },
  adminDashboard: {
    noPendingProfiles: { [Language.EN]: 'No pending profiles.', [Language.MR]: 'प्रलंबित प्रोफाइल नाहीत.', [Language.HI]: 'कोई लंबित प्रोफाइल नहीं है।' },
    noApprovedProfiles: { [Language.EN]: 'No approved profiles.', [Language.MR]: 'मंजूर प्रोफाइल नाहीत.', [Language.HI]: 'कोई स्वीकृत प्रोफाइल नहीं है।' },
    confirmations: {
        logout: { [Language.EN]: 'Are you sure you want to log out?', [Language.MR]: 'तुम्हाला खात्री आहे की तुम्हाला लॉग आउट करायचे आहे?', [Language.HI]: 'क्या आप वाकई लॉग आउट करना चाहते हैं?' },
        resetContent: { [Language.EN]: 'Are you sure you want to reset all content to default? This action cannot be undone.', [Language.MR]: 'तुम्हाला खात्री आहे की तुम्हाला सर्व सामग्री डीफॉल्टवर रीसेट करायची आहे? ही क्रिया पूर्ववत केली जाऊ शकत नाही.', [Language.HI]: 'क्या आप वाकई सारी सामग्री को डिफ़ॉल्ट पर रीसेट करना चाहते हैं? यह कार्रवाई पूर्ववत नहीं की जा सकती।' },
        deleteProfile: { [Language.EN]: 'Are you sure you want to permanently delete this profile?', [Language.MR]: 'तुम्हाला खात्री आहे की तुम्हाला हे प्रोफाइल कायमचे हटवायचे आहे?', [Language.HI]: 'क्या आप वाकई इस प्रोफ़ाइल को स्थायी रूप से हटाना चाहते हैं?' },
        changeProfileStatus: { [Language.EN]: 'Are you sure you want to change the status of this profile?', [Language.MR]: 'तुम्हाला खात्री आहे की तुम्हाला या प्रोफाइलची स्थिती बदलायची आहे?', [Language.HI]: 'क्या आप वाकई इस प्रोफ़ाइल की स्थिति बदलना चाहते हैं?' },
    }
  },
   marriageProfiles: [
    // FIX: Added missing 'consent' property to conform to the MarriageProfile type.
    {
      id: uuidv4(), status: 'approved', name: 'Priya Sharma', gender: 'Female', photo: 'https://images.pexels.com/photos/1181690/pexels-photo-1181690.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', dob: '1995-05-15', address: 'Pune', phone: '123', email: 'a@b.com',
      fatherName: 'Rajesh Sharma', motherName: 'Sunita Sharma', sisters: '1', brothers: '0', job: 'Software Engineer', salary: '12 LPA', education: 'B.E. Computer Science',
      gotra: 'Bharadwaj', caste: 'Brahmin', religion: 'Hindu', expectations: 'Looking for a well-educated, caring partner from a good family.', consent: true
    },
    // FIX: Added missing 'consent' property to conform to the MarriageProfile type.
    {
      id: uuidv4(), status: 'approved', name: 'Amit Patil', gender: 'Male', photo: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', dob: '1992-08-20', address: 'Nashik', phone: '123', email: 'a@b.com',
      fatherName: 'Suresh Patil', motherName: 'Meena Patil', sisters: '0', brothers: '1', job: 'Doctor', salary: '20 LPA', education: 'MBBS, MD',
      gotra: 'Kashyap', caste: 'Maratha', religion: 'Hindu', expectations: 'Seeking a professionally qualified and understanding partner.', consent: true
    },
    // FIX: Added missing 'consent' property to conform to the MarriageProfile type.
    {
      id: uuidv4(), status: 'pending', name: 'Sunaina Gupta', gender: 'Female', photo: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', dob: '1996-11-01', address: 'Mumbai', phone: '123', email: 'a@b.com',
      fatherName: 'Anil Gupta', motherName: 'Rekha Gupta', sisters: '1', brothers: '1', job: 'Architect', salary: '10 LPA', education: 'B.Arch',
      gotra: 'Garg', caste: 'Vaishya', religion: 'Hindu', expectations: 'A creative and ambitious partner who values family.', consent: true
    },
    // FIX: Added missing 'consent' property to conform to the MarriageProfile type.
    {
      id: uuidv4(), status: 'approved', name: 'Rohan Joshi', gender: 'Male', photo: 'https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', dob: '1990-02-25', address: 'Nagpur', phone: '123', email: 'a@b.com',
      fatherName: 'Sanjay Joshi', motherName: 'Anjali Joshi', sisters: '1', brothers: '0', job: 'Civil Engineer', salary: '15 LPA', education: 'M.Tech',
      gotra: 'Atri', caste: 'Brahmin', religion: 'Hindu', expectations: 'An independent and family-oriented partner.', consent: true
    },
    // FIX: Added missing 'consent' property to conform to the MarriageProfile type.
    {
      id: uuidv4(), status: 'approved', name: 'Sneha Reddy', gender: 'Female', photo: 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', dob: '1997-07-12', address: 'Hyderabad', phone: '123', email: 'a@b.com',
      fatherName: 'Murali Reddy', motherName: 'Laxmi Reddy', sisters: '0', brothers: '1', job: 'Data Scientist', salary: '18 LPA', education: 'M.S. in Data Science',
      gotra: 'Vashishta', caste: 'Reddy', religion: 'Hindu', expectations: 'Someone who is ambitious, witty, and loves to travel.', consent: true
    },
    // FIX: Added missing 'consent' property to conform to the MarriageProfile type.
    {
      id: uuidv4(), status: 'approved', name: 'Vikram Singh', gender: 'Male', photo: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', dob: '1991-12-30', address: 'Jaipur', phone: '123', email: 'a@b.com',
      fatherName: 'Ajay Singh', motherName: 'Kiran Singh', sisters: '2', brothers: '0', job: 'Hotel Manager', salary: '14 LPA', education: 'BHM',
      gotra: 'Rathore', caste: 'Rajput', religion: 'Hindu', expectations: 'A partner who appreciates culture and traditions.', consent: true
    },
    // FIX: Added missing 'consent' property to conform to the MarriageProfile type.
    {
      id: uuidv4(), status: 'pending', name: 'Anika Desai', gender: 'Female', photo: 'https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', dob: '1998-01-18', address: 'Ahmedabad', phone: '123', email: 'a@b.com',
      fatherName: 'Paresh Desai', motherName: 'Hina Desai', sisters: '1', brothers: '0', job: 'Graphic Designer', salary: '8 LPA', education: 'B.Des',
      gotra: 'Kapil', caste: 'Patel', religion: 'Hindu', expectations: 'A creative soul with a good sense of humor.', consent: true
    },
    // FIX: Added missing 'consent' property to conform to the MarriageProfile type.
    {
      id: uuidv4(), status: 'approved', name: 'Karan Malhotra', gender: 'Male', photo: 'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', dob: '1989-09-05', address: 'Delhi', phone: '123', email: 'a@b.com',
      fatherName: 'Ravi Malhotra', motherName: 'Poonam Malhotra', sisters: '0', brothers: '0', job: 'Lawyer', salary: '25 LPA', education: 'LLB',
      gotra: 'Kashyap', caste: 'Khatri', religion: 'Hindu', expectations: 'An intelligent and compassionate partner.', consent: true
    },
    // FIX: Added missing 'consent' property to conform to the MarriageProfile type.
    {
      id: uuidv4(), status: 'approved', name: 'Meera Iyer', gender: 'Female', photo: 'https://images.pexels.com/photos/762020/pexels-photo-762020.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', dob: '1994-04-22', address: 'Chennai', phone: '123', email: 'a@b.com',
      fatherName: 'Shankar Iyer', motherName: 'Padma Iyer', sisters: '1', brothers: '1', job: 'Chartered Accountant', salary: '16 LPA', education: 'CA',
      gotra: 'Agastya', caste: 'Iyer', religion: 'Hindu', expectations: 'A simple, honest and understanding person.', consent: true
    },
    // FIX: Added missing 'consent' property to conform to the MarriageProfile type.
    {
      id: uuidv4(), status: 'approved', name: 'Aditya Mehta', gender: 'Male', photo: 'https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', dob: '1993-06-10', address: 'Kolkata', phone: '123', email: 'a@b.com',
      fatherName: 'Vikas Mehta', motherName: 'Sarla Mehta', sisters: '1', brothers: '0', job: 'Marketing Manager', salary: '17 LPA', education: 'MBA',
      gotra: 'Sandilya', caste: 'Jain', religion: 'Jain', expectations: 'Looking for a modern, open-minded partner.', consent: true
    },
    // FIX: Added missing 'consent' property to conform to the MarriageProfile type.
     {
      id: uuidv4(), status: 'pending', name: 'Fatima Khan', gender: 'Female', photo: 'https://images.pexels.com/photos/1024311/pexels-photo-1024311.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', dob: '1996-03-28', address: 'Lucknow', phone: '123', email: 'a@b.com',
      fatherName: 'Irfan Khan', motherName: 'Zoya Khan', sisters: '2', brothers: '1', job: 'Teacher', salary: '6 LPA', education: 'M.A., B.Ed',
      gotra: 'N/A', caste: 'Khan', religion: 'Islam', expectations: 'A respectful and educated partner from a decent family.', consent: true
    },
    // FIX: Added missing 'consent' property to conform to the MarriageProfile type.
    {
      id: uuidv4(), status: 'approved', name: 'Jaspreet Kaur', gender: 'Female', photo: 'https://images.pexels.com/photos/1382731/pexels-photo-1382731.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', dob: '1995-10-02', address: 'Chandigarh', phone: '123', email: 'a@b.com',
      fatherName: 'Harvinder Singh', motherName: 'Manjeet Kaur', sisters: '0', brothers: '1', job: 'Bank PO', salary: '9 LPA', education: 'M.Com',
      gotra: 'Dhillon', caste: 'Jat Sikh', religion: 'Sikhism', expectations: 'A well-settled and family-oriented person.', consent: true
    }
   ]
};