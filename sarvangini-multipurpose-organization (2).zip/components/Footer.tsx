// FIX: Create the `Footer` component.
import React from 'react';
import { NavLink } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { useContent } from '../context/ContentContext';
import { FacebookIcon, InstagramIcon, TwitterIcon, YoutubeIcon } from './IconComponents';

export const Footer = () => {
  const { language, getFontClass } = useLanguage();
  const { content } = useContent();
  const fontClass = getFontClass();
  const c = content.footer;
  const navContent = content.nav;

  const quickLinks = [
    { to: '/', label: navContent.home[language] },
    { to: '/about-us', label: navContent.about[language] },
    { to: '/marriage', label: navContent.marriage[language] },
    { to: '/social-work', label: navContent.socialWork[language] },
    { to: '/contact-us', label: navContent.contact[language] },
  ];

  return (
    <footer className="bg-surface text-text border-t border-border-color">
      <div className="container mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* About Section */}
          <div>
            <h3 className={`text-2xl font-bold mb-4 text-secondary ${fontClass}`}>{content.appName[language]}</h3>
            <p className={`text-light-text ${fontClass}`}>{content.tagline[language]}</p>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className={`text-xl font-semibold mb-4 ${fontClass}`}>{c.quickLinks[language]}</h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.to}>
                  <NavLink to={link.to} className={`text-light-text hover:text-accent transition-colors duration-200 ${fontClass}`}>
                    {link.label}
                  </NavLink>
                </li>
              ))}
            </ul>
          </div>

          {/* Follow Us */}
          <div>
            <h3 className={`text-xl font-semibold mb-4 ${fontClass}`}>{c.followUs[language]}</h3>
            <div className="flex space-x-4">
              {c.facebookUrl && <a href={c.facebookUrl} target="_blank" rel="noopener noreferrer" className="text-light-text hover:text-primary-hover transition-colors duration-200"><FacebookIcon /></a>}
              {c.instagramUrl && <a href={c.instagramUrl} target="_blank" rel="noopener noreferrer" className="text-light-text hover:text-primary-hover transition-colors duration-200"><InstagramIcon /></a>}
              {c.youtubeUrl && <a href={c.youtubeUrl} target="_blank" rel="noopener noreferrer" className="text-light-text hover:text-primary-hover transition-colors duration-200"><YoutubeIcon /></a>}
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-border-color text-center">
          <p className={`text-light-text ${fontClass}`}>{c.copyright[language]}</p>
        </div>
      </div>
    </footer>
  );
};