export enum Language {
  EN = 'en',
  MR = 'mr',
  HI = 'hi',
}

export type LocalizedString = {
  [key in Language]: string;
};

export interface SocialWorkImage {
    id: string;
    src: string;
    caption: LocalizedString;
}

export interface SocialWorkCategory {
    id: string;
    title: LocalizedString;
    images: SocialWorkImage[];
}

export interface TeamMember {
    id: string;
    name: string;
    role: LocalizedString;
    vision: LocalizedString;
    photo: string;
    contact?: string;
    email?: string;
}

export interface MarriageProfile {
  id: string;
  status: 'approved' | 'pending';
  name: string;
  gender: 'Male' | 'Female' | 'Other';
  photo: string;
  dob: string;
  address: string;
  phone: string;
  email: string;
  fatherName: string;
  motherName: string;
  sisters: string;
  brothers: string;
  job: string;
  salary: string;
  education: string;
  gotra: string;
  caste: string;
  religion: string;
  expectations: string;
  consent: boolean;
}

export interface SiteContent {
  appName: LocalizedString;
  tagline: LocalizedString;
  languageSelector: LocalizedString;
  header: {
    toggleTheme: LocalizedString;
    openMenu: LocalizedString;
    languageNames: {
      en: LocalizedString;
      mr: LocalizedString;
      hi: LocalizedString;
    }
  };
  nav: {
    home: LocalizedString;
    marriage: LocalizedString;
    profiles: LocalizedString;
    socialWork: LocalizedString;
    about: LocalizedString;
    contact: LocalizedString;
    donate: LocalizedString;
    adminLogin: LocalizedString;
  };
  homepage: {
    heroImage: string;
    welcomeMessage: LocalizedString;
    quickLinks: {
      marriageTitle: LocalizedString;
      marriageDesc: LocalizedString;
      socialWorkTitle: LocalizedString;
      socialWorkDesc: LocalizedString;
    };
  };
  marriageSection: {
    title: LocalizedString;
    subheading: LocalizedString;
    description: LocalizedString;
    oneStopSolution: {
      title: LocalizedString;
      items: LocalizedString[];
    };
    form: {
      title: LocalizedString;
      personalDetails: LocalizedString;
      name: LocalizedString;
      gender: LocalizedString;
      male: LocalizedString;
      female: LocalizedString;
      other: LocalizedString;
      photo: LocalizedString;
      dob: LocalizedString;
      address: LocalizedString;
      phone: LocalizedString;
      email: LocalizedString;
      familyDetails: LocalizedString;
      fatherName: LocalizedString;
      motherName: LocalizedString;
      sisters: LocalizedString;
      brothers: LocalizedString;
      professionalDetails: LocalizedString;
      job: LocalizedString;
      salary: LocalizedString;
      education: LocalizedString;
      culturalDetails: LocalizedString;
      gotra: LocalizedString;
      caste: LocalizedString;
      religion: LocalizedString;
      expectations: LocalizedString;
      consent: LocalizedString;
      submit: LocalizedString;
      paymentTitle: LocalizedString;
      paymentDesc: LocalizedString;
      formSuccess: LocalizedString;
      formSuccessSub: LocalizedString;
      sendBiodata: LocalizedString;
      sendTo: LocalizedString;
    };
    filters: {
      title: LocalizedString;
      ageRange: LocalizedString;
      from: LocalizedString;
      to: LocalizedString;
      caste: LocalizedString;
      education: LocalizedString;
      search: LocalizedString;
      gender: {
        label: LocalizedString;
        all: LocalizedString;
        male: LocalizedString;
        female: LocalizedString;
        other: LocalizedString;
      };
    };
  };
  profilesPage: {
    title: LocalizedString;
    noProfiles: LocalizedString;
    contactAction: LocalizedString;
    ageString: LocalizedString;
    details: {
        education: LocalizedString;
        occupation: LocalizedString;
        caste: LocalizedString;
    };
    interestMessage: LocalizedString;
  };
  socialWork: {
    title: LocalizedString;
    galleryTitle: LocalizedString;
    categories: SocialWorkCategory[];
    donateTitle: LocalizedString;
    donateDesc: LocalizedString;
    donateButton: LocalizedString;
  };
  aboutUs: {
    title: LocalizedString;
    vision: LocalizedString;
    mission: LocalizedString;
    history: LocalizedString;
    visionText: LocalizedString;
    missionText: LocalizedString;
    historyText: LocalizedString;
    teamTitle: LocalizedString;
    teamDetails: {
        phone: LocalizedString;
        email: LocalizedString;
    };
    team: TeamMember[];
  };
  contactUs: {
    title: LocalizedString;
    getInTouch: LocalizedString;
    phones: { name: string; number: string }[];
    email: string;
    address: LocalizedString;
    mapEmbedUrl: string;
    labels: {
        phone: LocalizedString;
        email: LocalizedString;
        address: LocalizedString;
    };
  };
  donatePage: {
    title: LocalizedString;
    supportCause: LocalizedString;
    scanToPay: LocalizedString;
    directTransfer: LocalizedString;
    upiId: string;
    bankAccount: string;
    qrCode: string;
  };
  footer: {
    copyright: LocalizedString;
    quickLinks: LocalizedString;
    followUs: LocalizedString;
    adminLogin: LocalizedString;
    facebookUrl: string;
    instagramUrl: string;
    youtubeUrl: string;
  };
  adminDashboard: {
    noPendingProfiles: LocalizedString;
    noApprovedProfiles: LocalizedString;
    confirmations: {
      logout: LocalizedString;
      resetContent: LocalizedString;
      deleteProfile: LocalizedString;
      changeProfileStatus: LocalizedString;
    };
  };
  marriageProfiles: MarriageProfile[];
}