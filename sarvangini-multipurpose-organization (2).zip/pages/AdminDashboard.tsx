import React, { useState, PropsWithChildren } from 'react';
import { useNavigate } from 'react-router-dom';
import { useContent } from '../context/ContentContext';
import { SiteContent, Language, LocalizedString, SocialWorkCategory, TeamMember, MarriageProfile } from '../types';
import { DEFAULT_CONTENT } from '../constants';
import { v4 as uuidv4 } from 'uuid';
import { useLanguage } from '../context/LanguageContext';


// Accordion Component
const Accordion = ({ title, children }: PropsWithChildren<{title: string}>) => {
    const [isOpen, setIsOpen] = useState(false);
    return (
        <div className="border border-border-color rounded-md mb-2">
            <button
                type="button"
                onClick={() => setIsOpen(!isOpen)}
                className="w-full bg-surface p-4 text-left font-semibold flex justify-between items-center hover:bg-background"
            >
                {title}
                <svg className={`w-5 h-5 transform transition-transform ${isOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                </svg>
            </button>
            {isOpen && <div className="p-4 bg-background">{children}</div>}
        </div>
    );
};


const AdminDashboard = () => {
  const { content, setContent } = useContent();
  const { language } = useLanguage();
  const [formData, setFormData] = useState<SiteContent>(content);
  const navigate = useNavigate();
  const c = content.adminDashboard.confirmations;

  const handleLogout = () => {
    if (window.confirm(c.logout[language])) {
        sessionStorage.removeItem('sarvangini-admin-auth');
        navigate('/admin-login');
    }
  };

  const handleResetContent = () => {
    if (window.confirm(c.resetContent[language])) {
        setContent(DEFAULT_CONTENT);
        setFormData(DEFAULT_CONTENT);
        alert('Content has been reset to default.');
    }
  }
  
  const handleInputChange = (path: string, value: any, index?: number, field?: string) => {
    setFormData(prev => {
        const newFormData = JSON.parse(JSON.stringify(prev)); // Deep copy
        const keys = path.split('.');
        let current = newFormData as any;
        for (let i = 0; i < keys.length; i++) {
            if (i === keys.length - 1) {
                if(index !== undefined && field) {
                    current[keys[i]][index][field] = value;
                } else if (index !== undefined) {
                    current[keys[i]][index] = value;
                }
                else {
                    current[keys[i]] = value;
                }
            } else {
                current = current[keys[i]];
            }
        }
        return newFormData;
    });
};

  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setContent(formData);
    alert('Content updated successfully!');
  };
  
  // COMPONENTS FOR FORM
  const LocalizedInput = ({ path, label }: { path: string, label: string }) => {
    const keys = path.split('.');
    let value: LocalizedString = formData as any;
    try {
        keys.forEach(key => value = value?.[key]);
        if (!value) throw new Error("Path not found");
    } catch(e) {
        return <div className="text-red-500">Error: Invalid path "{path}"</div>;
    }


    return (
        <div className="mb-4">
            <label className="block text-light-text text-sm font-bold mb-2">{label}</label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <input className="input-themed" value={value[Language.EN]} onChange={e => handleInputChange(`${path}.${Language.EN}`, e.target.value)} placeholder="English"/>
                <input className="input-themed font-marathi" value={value[Language.MR]} onChange={e => handleInputChange(`${path}.${Language.MR}`, e.target.value)} placeholder="Marathi"/>
                <input className="input-themed font-hindi" value={value[Language.HI]} onChange={e => handleInputChange(`${path}.${Language.HI}`, e.target.value)} placeholder="Hindi"/>
            </div>
        </div>
    );
  };
  
  const TextInput = ({ path, label, isTextArea=false }: { path: string, label: string, isTextArea?: boolean }) => {
     const keys = path.split('.');
    let value: string = formData as any;
    try {
        keys.forEach(key => value = value?.[key]);
    } catch(e) {
        return <div className="text-red-500">Error: Invalid path "{path}"</div>;
    }
    
    const InputComponent = isTextArea ? 'textarea' : 'input';

    return (
        <div className="mb-4">
            <label className="block text-light-text text-sm font-bold mb-2">{label}</label>
            <InputComponent className="input-themed" value={value || ''} onChange={(e: any) => handleInputChange(path, e.target.value)} placeholder={label}/>
        </div>
    )
  }

  const fileToBase64 = (file: File): Promise<string> => {
      return new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.readAsDataURL(file);
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = error => reject(error);
      });
  }
  
  // Marriage Profile Management
  const handleProfileStatusChange = (profileId: string, status: 'approved' | 'pending') => {
      if (window.confirm(c.changeProfileStatus[language])) {
        const updatedProfiles = formData.marriageProfiles.map(p => p.id === profileId ? {...p, status} : p);
        handleInputChange('marriageProfiles', updatedProfiles);
      }
  }

  const deleteProfile = (profileId: string) => {
      if (window.confirm(c.deleteProfile[language])) {
          const updatedProfiles = formData.marriageProfiles.filter(p => p.id !== profileId);
          handleInputChange('marriageProfiles', updatedProfiles);
      }
  }

  // Social Work Management
  const handleSocialWorkImageUpload = async (catIndex: number, imgIndex: number, file: File) => {
      const base64 = await fileToBase64(file);
      const updatedCategories = [...formData.socialWork.categories];
      updatedCategories[catIndex].images[imgIndex].src = base64;
      handleInputChange('socialWork.categories', updatedCategories);
  }

  // Team Member Management
  const handleTeamMemberPhotoUpload = async (memberIndex: number, file: File) => {
    const base64 = await fileToBase64(file);
    const updatedTeam = [...formData.aboutUs.team];
    updatedTeam[memberIndex].photo = base64;
    handleInputChange('aboutUs.team', updatedTeam);
  }
    
  const handleHomepageImageUpload = async (file: File) => {
    const base64 = await fileToBase64(file);
    handleInputChange('homepage.heroImage', base64);
  }
  
  const handleQrCodeImageUpload = async (file: File) => {
    const base64 = await fileToBase64(file);
    handleInputChange('donatePage.qrCode', base64);
  }

  const pendingProfiles = formData.marriageProfiles.filter(p => p.status === 'pending');
  const approvedProfiles = formData.marriageProfiles.filter(p => p.status === 'approved');

  return (
    <div className="container mx-auto p-4 md:p-8 fade-in">
      <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
        <h1 className="text-2xl md:text-3xl font-bold text-text">Admin Dashboard</h1>
        <div>
            <button onClick={handleResetContent} className="bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded mr-2">Reset to Default</button>
            <button onClick={handleLogout} className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">Logout</button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="bg-surface shadow-md rounded px-4 md:px-8 pt-6 pb-8 mb-4 border border-border-color">
        
        <Accordion title="Marriage Profile Management">
            <div className="space-y-4">
                <h3 className="text-lg font-semibold text-text">Pending Profiles ({pendingProfiles.length})</h3>
                {pendingProfiles.length > 0 ? (
                    pendingProfiles.map(profile => (
                        <div key={profile.id} className="border border-border-color p-4 rounded-md flex justify-between items-center">
                            <div>
                                <p className="font-bold text-text">{profile.name}, {profile.gender}</p>
                                <p className="text-sm text-light-text">{profile.address}</p>
                            </div>
                            <div>
                                <button type="button" onClick={() => handleProfileStatusChange(profile.id, 'approved')} className="bg-green-500 text-white px-3 py-1 rounded-md mr-2">Approve</button>
                                <button type="button" onClick={() => deleteProfile(profile.id)} className="bg-red-500 text-white px-3 py-1 rounded-md">Delete</button>
                            </div>
                        </div>
                    ))
                ) : (
                    <p className="text-light-text italic">{content.adminDashboard.noPendingProfiles[language]}</p>
                )}
                 <h3 className="text-lg font-semibold mt-6 text-text">Approved Profiles ({approvedProfiles.length})</h3>
                 {approvedProfiles.length > 0 ? (
                    approvedProfiles.map(profile => (
                        <div key={profile.id} className="border border-border-color p-4 rounded-md flex justify-between items-center">
                            <div>
                                <p className="font-bold text-text">{profile.name}, {profile.gender}</p>
                                <p className="text-sm text-light-text">{profile.address}</p>
                            </div>
                            <div>
                                <button type="button" onClick={() => handleProfileStatusChange(profile.id, 'pending')} className="bg-yellow-500 text-white px-3 py-1 rounded-md mr-2">Make Pending</button>
                                <button type="button" onClick={() => deleteProfile(profile.id)} className="bg-red-500 text-white px-3 py-1 rounded-md">Delete</button>
                            </div>
                        </div>
                    ))
                 ) : (
                    <p className="text-light-text italic">{content.adminDashboard.noApprovedProfiles[language]}</p>
                 )}
            </div>
        </Accordion>
        
        <Accordion title="General & Navigation Text">
            <LocalizedInput path="appName" label="Website Name" />
            <LocalizedInput path="tagline" label="Tagline" />
            <hr className="my-4 border-border-color"/>
            <h3 className="text-lg font-semibold mb-2 text-text">Navigation Links</h3>
            <LocalizedInput path="nav.home" label="Home" />
            <LocalizedInput path="nav.marriage" label="Marriage Bureau" />
            <LocalizedInput path="nav.profiles" label="Profiles" />
            <LocalizedInput path="nav.socialWork" label="Social Work" />
            <LocalizedInput path="nav.about" label="About Us" />
            <LocalizedInput path="nav.contact" label="Contact Us" />
            <LocalizedInput path="nav.donate" label="Donate" />
        </Accordion>

        <Accordion title="Homepage Content">
             <LocalizedInput path="homepage.welcomeMessage" label="Welcome Message" />
             <LocalizedInput path="homepage.quickLinks.marriageTitle" label="Marriage Card Title" />
             <LocalizedInput path="homepage.quickLinks.marriageDesc" label="Marriage Card Description" />
             <LocalizedInput path="homepage.quickLinks.socialWorkTitle" label="Social Work Card Title" />
             <LocalizedInput path="homepage.quickLinks.socialWorkDesc" label="Social Work Card Description" />
             <div className="border-t border-border-color pt-4 mt-4">
                <label className="block text-light-text text-sm font-bold mb-2">Homepage Banner Image</label>
                <img src={formData.homepage.heroImage} alt="Homepage Banner" className="w-full h-48 object-cover rounded-md mb-2"/>
                <input type="file" accept="image/*" onChange={e => e.target.files && handleHomepageImageUpload(e.target.files[0])} />
             </div>
        </Accordion>

         <Accordion title="Social Work Page">
            <LocalizedInput path="socialWork.title" label="Page Title" />
            <LocalizedInput path="socialWork.galleryTitle" label="Gallery Title" />
            <hr className="my-4"/>
            {formData.socialWork.categories.map((category, catIndex) => (
                <div key={category.id} className="border border-border-color p-4 rounded-md mb-4">
                    <LocalizedInput path={`socialWork.categories.${catIndex}.title`} label={`Category ${catIndex + 1} Title`} />
                    <h4 className="text-md font-semibold mt-4 mb-2 text-text">Images</h4>
                    {category.images.map((image, imgIndex) => (
                         <div key={image.id} className="border-t border-border-color pt-4 mt-4">
                            <LocalizedInput path={`socialWork.categories.${catIndex}.images.${imgIndex}.caption`} label={`Image ${imgIndex + 1} Caption`} />
                            <div className="mt-2">
                               <label className="block text-light-text text-sm font-bold mb-2">Image {imgIndex + 1}</label>
                                <img src={image.src} alt="Social work" className="w-48 h-32 object-cover rounded-md mb-2"/>
                                <input type="file" accept="image/*" onChange={e => e.target.files && handleSocialWorkImageUpload(catIndex, imgIndex, e.target.files[0])} />
                            </div>
                         </div>
                    ))}
                </div>
            ))}
             <hr className="my-4"/>
            <LocalizedInput path="socialWork.donateTitle" label="Donate Section Title" />
            <LocalizedInput path="socialWork.donateDesc" label="Donate Section Description" />
            <LocalizedInput path="socialWork.donateButton" label="Donate Section Button Text" />
        </Accordion>

        <Accordion title="About Us Page">
            <LocalizedInput path="aboutUs.title" label="Page Title" />
            <LocalizedInput path="aboutUs.vision" label="'Vision' Section Title" />
            <LocalizedInput path="aboutUs.visionText" label="Vision Text" />
            <LocalizedInput path="aboutUs.mission" label="'Mission' Section Title" />
            <LocalizedInput path="aboutUs.missionText" label="Mission Text" />
            <LocalizedInput path="aboutUs.history" label="'History' Section Title" />
            <LocalizedInput path="aboutUs.historyText" label="History Text" />
            <hr className="my-4"/>
            <LocalizedInput path="aboutUs.teamTitle" label="Team Section Title" />
            {formData.aboutUs.team.map((member, index) => (
                <div key={member.id} className="border border-border-color p-4 rounded-md mb-4">
                    <TextInput path={`aboutUs.team.${index}.name`} label="Member Name" />
                    <LocalizedInput path={`aboutUs.team.${index}.role`} label="Member Role" />
                    <LocalizedInput path={`aboutUs.team.${index}.vision`} label="Member Vision" />
                    <TextInput path={`aboutUs.team.${index}.contact`} label="Member Contact" />
                    <TextInput path={`aboutUs.team.${index}.email`} label="Member Email" />
                    <div className="mt-2">
                        <label className="block text-light-text text-sm font-bold mb-2">Member Photo</label>
                        <img src={member.photo} alt={member.name} className="w-24 h-24 rounded-full object-cover mb-2"/>
                        <input type="file" accept="image/*" onChange={e => e.target.files && handleTeamMemberPhotoUpload(index, e.target.files[0])} />
                    </div>
                </div>
            ))}
        </Accordion>

         <Accordion title="Contact Us Page">
             <LocalizedInput path="contactUs.title" label="Page Title"/>
             <LocalizedInput path="contactUs.getInTouch" label="Get In Touch Title"/>
             <TextInput path="contactUs.email" label="Email Address" />
             <LocalizedInput path="contactUs.address" label="Address" />
             <TextInput path="contactUs.mapEmbedUrl" label="Google Maps Embed URL" isTextArea={true} />
             <hr className="my-4"/>
             <h3 className="text-lg font-semibold mb-2 text-text">Phone Numbers</h3>
             {formData.contactUs.phones.map((phone, index) => (
                <div key={index} className="border p-2 rounded-md mb-2 flex items-center gap-2">
                    <input className="input-themed" value={phone.name} onChange={e => handleInputChange('contactUs.phones', e.target.value, index, 'name')} placeholder="Name"/>
                    <input className="input-themed" value={phone.number} onChange={e => handleInputChange('contactUs.phones', e.target.value, index, 'number')} placeholder="Number"/>
                    <button type="button" onClick={() => handleInputChange('contactUs.phones', formData.contactUs.phones.filter((_, i) => i !== index))} className="bg-red-500 text-white p-2 rounded-md">X</button>
                </div>
             ))}
             <button type="button" onClick={() => handleInputChange('contactUs.phones', [...formData.contactUs.phones, {name: '', number: ''}])} className="bg-blue-500 text-white p-2 rounded-md mt-2">Add Phone</button>
        </Accordion>
        
        <Accordion title="Donate Page">
            <LocalizedInput path="donatePage.title" label="Page Title" />
            <LocalizedInput path="donatePage.supportCause" label="Support Cause Text" />
            <LocalizedInput path="donatePage.scanToPay" label="Scan to Pay Text" />
            <LocalizedInput path="donatePage.directTransfer" label="Direct Transfer Text" />
            <TextInput path="donatePage.upiId" label="UPI ID" />
            <TextInput path="donatePage.bankAccount" label="Bank Account Number" />
            <div className="border-t border-border-color pt-4 mt-4">
                <label className="block text-light-text text-sm font-bold mb-2">Donation QR Code</label>
                <img src={formData.donatePage.qrCode} alt="Donation QR" className="w-48 h-48 object-cover rounded-md mb-2 bg-white p-2"/>
                <input type="file" accept="image/*" onChange={e => e.target.files && handleQrCodeImageUpload(e.target.files[0])} />
             </div>
        </Accordion>

        <Accordion title="Footer">
            <LocalizedInput path="footer.copyright" label="Copyright Text" />
            <TextInput path="footer.facebookUrl" label="Facebook URL" />
            <TextInput path="footer.instagramUrl" label="Instagram URL" />
            <TextInput path="footer.youtubeUrl" label="YouTube URL" />
        </Accordion>

        <div className="flex items-center justify-center mt-6">
          <button
            className="bg-primary hover:bg-primary-hover text-white font-bold py-2 px-6 rounded-lg text-lg focus:outline-none focus:shadow-outline btn-press"
            type="submit"
          >
            Save All Changes
          </button>
        </div>
      </form>
    </div>
  );
};

export default AdminDashboard;