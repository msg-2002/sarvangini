import React from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { useContent } from '../context/ContentContext';

const HomePage = () => {
  const { language, getFontClass } = useLanguage();
  const { content } = useContent();
  const c = content.homepage;
  const founder = content.aboutUs.team.find(m => m.id === 'nandini-gadakh');

  return (
    <div className="bg-background fade-in">
      {/* Main Banner */}
      <section 
        className="relative bg-cover bg-center text-white py-40 px-4 sm:px-6 lg:px-8" 
        style={{ backgroundImage: `url('${c.heroImage}')` }}
      >
        <div className="absolute inset-0 bg-black opacity-60"></div>
        <div className="relative container mx-auto text-center">
          <h1 className={`text-5xl md:text-6xl font-serif font-bold mb-4 text-white text-shadow-custom ${getFontClass()}`}>{content.appName[language]}</h1>
          <p className={`text-xl md:text-2xl text-gray-200 text-shadow-custom ${getFontClass()}`}>{content.tagline[language]}</p>
        </div>
      </section>

      {/* Welcome Message */}
      <section className="py-20 bg-surface">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className={`text-xl text-light-text max-w-4xl mx-auto leading-relaxed ${getFontClass()}`}>
            {c.welcomeMessage[language]}
          </p>
        </div>
      </section>

      {/* Quick Links Section */}
       <section className="py-20 bg-background border-y border-border-color">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="card-lift bg-surface p-8 rounded-lg shadow-lg text-center border border-border-color">
                    <h3 className={`text-3xl font-serif font-bold text-secondary mb-4 ${getFontClass()}`}>{c.quickLinks.marriageTitle[language]}</h3>
                    <p className={`text-light-text mb-6 ${getFontClass()}`}>{c.quickLinks.marriageDesc[language]}</p>
                    <Link to="/marriage" className="text-accent hover:text-accent/80 font-semibold transition-colors duration-300">
                        {content.nav.marriage[language]} &rarr;
                    </Link>
                </div>
                 <div className="card-lift bg-surface p-8 rounded-lg shadow-lg text-center border border-border-color">
                    <h3 className={`text-3xl font-serif font-bold text-secondary mb-4 ${getFontClass()}`}>{c.quickLinks.socialWorkTitle[language]}</h3>
                    <p className={`text-light-text mb-6 ${getFontClass()}`}>{c.quickLinks.socialWorkDesc[language]}</p>
                    <Link to="/social-work" className="text-accent hover:text-accent/80 font-semibold transition-colors duration-300">
                        {content.nav.socialWork[language]} &rarr;
                    </Link>
                </div>
            </div>
        </div>
       </section>
      
      {/* Founder Section */}
      {founder && (
        <section className="py-20 bg-surface">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex flex-wrap items-center justify-center text-center md:text-left">
                    <div className="w-full md:w-1/3 flex justify-center p-4">
                        <img src={founder.photo} alt={founder.name} className="w-64 h-64 rounded-full object-cover shadow-xl border-4 border-secondary"/>
                    </div>
                    <div className="w-full md:w-2/3 p-4">
                        <h3 className="text-2xl font-bold text-text mb-4">{founder.name}, <span className={`font-normal text-xl ${getFontClass()}`}>{founder.role[language]}</span></h3>
                        <p className={`text-lg text-light-text italic border-l-4 border-primary pl-6 ${getFontClass()}`}>"{founder.vision[language]}"</p>
                    </div>
                </div>
            </div>
        </section>
      )}

    </div>
  );
};

export default HomePage;